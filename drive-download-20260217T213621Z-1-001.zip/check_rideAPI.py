import requests
import sys
import time

def check_rides(target):
    base_url = f"http://{target}:8001"
    required_names = ["Raptor Dive", "Flight of the Quetzalcoatlus", "Jurassirail", "Volcanic Vortex", "Cretaceous Plains Safari", "Apex Containment Zone", "Nocturnal Encounters", "Lost to Time", "The Hatchery Live!"]
    required_names = sorted(required_names)

    try:
        res = requests.get(f"{base_url}/rides/")
        if res.status_code != 200:
            print(f"FAILURE: Could not access rides: {res.status_code}")
            return

        rides = res.json()
        names = sorted([ride["name"] for ride in rides])
        if names == required_names:
            print("CORRECT")
        else:
            print("FAILURE")


    except Exception as e:
        print(f"Connection failed: {e}")

if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: python check_rides.py <TARGET>")
        sys.exit(1)

    target = sys.argv[1]
    check_rides(target)
