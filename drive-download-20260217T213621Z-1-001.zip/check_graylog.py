#!/usr/bin/env python3
import sys
import requests
from requests.auth import HTTPBasicAuth
from datetime import datetime, timedelta
from urllib.parse import quote

def check_graylog_activity(target, token):
    """
    Checks if Graylog is reachable and receiving logs in the last 5 minutes.
    Optionally filters for beat-related logs if present.
    """
    headers = {
        "Accept": "application/json",
        "X-Requested-By": "API",
    }

    auth = HTTPBasicAuth(token, "token")
    now = datetime.utcnow()
    since = now - timedelta(minutes=5)

    query = "beat OR filebeat OR winlogbeat OR metricbeat"
    encoded_query = quote(query)

    url = f"http://{target}:9000/api/search/universal/relative?query={encoded_query}&range=300"

    try:
        response = requests.get(url, headers=headers, auth=auth)
        if response.status_code != 200:
            print(f"FAILURE: Graylog API returned {response.status_code}")
            print(response.text)
            return

        result = response.json()
        total_logs = result.get("total_results", 0)

        if total_logs > 0:
            print(f"✅ Graylog is working — {total_logs} logs found in the last 5 minutes. [CORRECT]")
        else:
            print("⚠️ Graylog reachable, but no logs in the last 5 minutes (check your inputs) [FAILURE].")

    except requests.exceptions.ConnectionError:
        print("❌ ERROR: Could not connect to Graylog — is it running and reachable?")
    except Exception as e:
        print(f"❌ ERROR: Unexpected issue: {e}")

if __name__ == "__main__":
    # if len(sys.argv) != 2:
    #     print("Usage: python check_graylog_activity.py <TARGET:9000> <GRAYLOG_TOKEN>")
    #     sys.exit(1)

    check_graylog_activity(sys.argv[1], sys.argv[2])
