import requests
import sys

REPOS_TO_CHECK = {
    "rideAPI": "rnormandy",
    "waitAPI": "codom",
    "GCWebapp": "ajordan",
    # "reusable-workflows": "greatcretaceous",
}

def check_gitea_latest_jobs(target, token):
    """
    Checks the latest job for each hardcoded Gitea repository and prints result per repo.

    :param target: Gitea server (e.g., 10.100.1.50)
    :param token: Gitea API token
    """
    base_url = f"http://{target}:3000/api/v1"
    headers = {
        "Authorization": f"token {token}",
        "Accept": "application/json"
    }

    any_failed = False

    for repo, owner in REPOS_TO_CHECK.items():
        print(f"Checking {owner}/{repo}...")

        try:
            runs_url = f"{base_url}/repos/{owner}/{repo}/actions/tasks"
            res = requests.get(runs_url, headers=headers)

            if res.status_code != 200:
                print(f"  FAILURE: Could not retrieve runs (HTTP {res.status_code})")
                any_failed = True
                continue
            
            runs = res.json().get("workflow_runs", [])

            if not runs:
                print("  FAILURE: No workflow runs found.")
                any_failed = True
                continue

            latest_tasks = [runs[0], runs[1]]
            if latest_tasks[0]["status"] != "success" or latest_tasks[1]["status"] != "success":
                print(f"FAILED JOB FOR {owner}/{repo}")
                any_failed = True

        except Exception as e:
            print(f"  Connection failed: {e}")
            any_failed = True

    if any_failed:
        print("FAILURE: One or more repositories had failing or missing jobs.")
    else:
        print("CORRECT: All latest jobs succeeded.")

if __name__ == "__main__":
    if len(sys.argv) != 3:
        print("Usage: python check_gitea_latest_jobs.py <TARGET> <TOKEN>")
        sys.exit(1)

    target = sys.argv[1]
    token = sys.argv[2]

    check_gitea_latest_jobs(target, token)
