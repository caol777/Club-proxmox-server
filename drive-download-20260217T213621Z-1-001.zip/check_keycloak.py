import requests
import sys

def check_keycloak_login(box_ip, username, password):
    keycloak_url = f"http://{box_ip}:8080"
    realm = "master"
    client_id = "account-console"

    url = f"{keycloak_url}/realms/{realm}/protocol/openid-connect/token"
    data = {
        "client_id": client_id,
        "username": username,
        "password": password,
        "grant_type": "password"
    }
    print(data)
    try:
        response = requests.post(url, data=data)
        if response.status_code == 200:
            print("CORRECT")
            # print("Access Token:", response.json().get("access_token"))
        else:
            print("FAILURE")
    except Exception as e:
        print("FAILURE")

if __name__ == "__main__":
    # Check if BOXIP, USERNAME, and PASSWORD are provided
    if len(sys.argv) != 4:
        print("Usage: python check_keycloak_login.py <BOXIP> <USERNAME> <PASSWORD>")
        sys.exit(1)

    box_ip = sys.argv[1]
    username = sys.argv[2]
    password = sys.argv[3]
    check_keycloak_login(box_ip, username, password)