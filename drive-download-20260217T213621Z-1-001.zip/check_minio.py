import requests

BUCKET = "dinosaur-inspiration"
TEST_FILE = "test.txt"
TEST_CONTENT = "uptime"
EXPECTED_FILES = [
    "211124180250-03-dinosaurs-paleoart-michael-benton-112421.jpg",
    # "81aQSAyElmL_UF894,1000_QL80_.jpg",
    # "Dinosaur_Train_PBSLM_Collection_Graphics_600×338_nolm.png",
    "favdinos_resized_dino.jpg",
    "favdinos_resized_littlefoot.jpg",
    "favdinos_resized_rex.jpg",
    "g4kppzhsxx3c1.jpg"
]

def check_minio_public(target: str):
    target = f"http://{target}:9000"
    # 1. Check existence of required files
    for file in EXPECTED_FILES:
        url = f"{target}/{BUCKET}/{file}"
        # print(url)
        resp = requests.get(url)
        # print(resp)
        if resp.status_code != 200:
            print(f"FAILURE: {file} not accessible.")
            return

    # 2. Upload test file
    upload_url = f"{target}/{BUCKET}/{TEST_FILE}"
    upload_resp = requests.put(upload_url, data=TEST_CONTENT.encode("utf-8"))
    if upload_resp.status_code != 200:
        print("FAILURE: Could not upload test.txt")
        return

    # 3. Retrieve test file
    get_resp = requests.get(upload_url)
    # print(get_resp.text)
    if get_resp.status_code != 200 or get_resp.text.strip() != TEST_CONTENT:
        print("FAILURE: Uploaded test.txt is incorrect or inaccessible.")
        return

    # 4. Delete test file
    delete_resp = requests.delete(upload_url)
    if delete_resp.status_code != 204:  # 204 No Content on successful delete
        print("FAILURE: Could not delete test.txt")
        return

    print("CORRECT")

if __name__ == "__main__":
    import sys
    if len(sys.argv) != 2:
        print("Usage: python check_rides.py <TARGET>")
        sys.exit(1)

    target = sys.argv[1]
    check_minio_public(target)