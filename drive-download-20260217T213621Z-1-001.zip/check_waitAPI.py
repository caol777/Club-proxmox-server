import requests
import sys
import time

def check_queue_adjustment(target, ride_id=1, count=2):
    """
    Adds to a ride queue, checks that the count increased, then removes it and ensures it went back to original.

    :param target: IP or domain of the FastAPI server (e.g., "10.100.1.123:8000")
    :param ride_id: The ride ID to check (default: 1)
    :param count: How many people to add/remove from queue (default: 2)
    """
    base_url = f"http://{target}:8000"
    headers = {"Content-Type": "application/json"}

    try:
        # Step 1: Get initial queue size
        res = requests.get(f"{base_url}/queue/{ride_id}")
        if res.status_code != 200:
            print(f"FAILURE: Could not get initial queue size. Status: {res.status_code}")
            return
        original_size = res.json().get("queue_size", -1)

        # Step 2: Add to queue
        add_payload = {"count": count}
        res = requests.post(f"{base_url}/queue/{ride_id}/add", json=add_payload, headers=headers)
        if res.status_code != 200:
            print(f"FAILURE: Could not add to queue. Status: {res.status_code}")
            return

        # Small delay to allow database to update
        time.sleep(0.5)

        # Step 3: Check updated queue size
        res = requests.get(f"{base_url}/queue/{ride_id}")
        updated_size = res.json().get("queue_size", -1)
        if updated_size != original_size + count:
            print(f"FAILURE: Queue did not update correctly. Expected {original_size + count}, got {updated_size}")
            return

        # Step 4: Remove from queue
        remove_payload = {"count": count}
        res = requests.post(f"{base_url}/queue/{ride_id}/remove", json=remove_payload, headers=headers)
        if res.status_code != 200:
            print(f"FAILURE: Could not remove from queue. Status: {res.status_code}")
            return

        # Small delay to allow database to update
        time.sleep(0.5)

        # Step 5: Check final queue size
        res = requests.get(f"{base_url}/queue/{ride_id}")
        final_size = res.json().get("queue_size", -1)

        if final_size == original_size:
            print("CORRECT")
        else:
            print(f"FAILURE: Final queue size incorrect. Expected {original_size}, got {final_size}")

    except Exception as e:
        print(f"Connection failed: {e}")

if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: python check_queue_adjustment.py <TARGET:PORT>")
        sys.exit(1)

    target = sys.argv[1]
    check_queue_adjustment(target)
